<ul>
    <li>Full body</li>
        <ul>
            <li>
                <a href="/Kristian/listeMedØkter/Fullbody1">Fullbody nr 1</a>
            </li>
        </ul>
    <li>Legs</li>
        <ul>
            <li>
                <a href="/Kristian/listeMedØkter/Legs1">Legs 1</a>
            </li>
        </ul>

</ul>

<div class="tilbake"><a href="/">Tilbake</a></div>
